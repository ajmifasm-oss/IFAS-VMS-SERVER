[CmdletBinding()]
param(
    [string]$Configuration = "Release",
    [string]$OutputRoot = "$PSScriptRoot\Published"
)

$ErrorActionPreference = "Stop"

$projects = @{
    Server = "..\01-IFAS-VMS-SERVER\IFAS.Server.csproj"
    Client = "..\03-IFAS-VMS-CLIENT\IFAS.VMS.Client.csproj"
    LicenseManager = "..\02-IFAS-LICENSE-MANAGER\IFAS.LicenseManager.csproj"
}

New-Item -ItemType Directory -Force -Path $OutputRoot | Out-Null

foreach ($name in $projects.Keys) {
    $project = Join-Path $PSScriptRoot $projects[$name]
    $destination = Join-Path $OutputRoot $name

    if (-not (Test-Path $project)) {
        Write-Warning "Project not found: $project"
        continue
    }

    Write-Host "Publishing $name..." -ForegroundColor Cyan
    dotnet publish $project -c $Configuration -r win-x64 --self-contained false -o $destination
    if ($LASTEXITCODE -ne 0) {
        throw "Publish failed for $name."
    }
}

Write-Host "Publish step complete." -ForegroundColor Green
